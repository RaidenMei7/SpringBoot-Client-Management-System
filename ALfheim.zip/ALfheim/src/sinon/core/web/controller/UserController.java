package sinon.core.web.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import sinon.core.entity.User;
import sinon.core.service.UserService;


@Controller
public class UserController {
	// ����ע��
		@Autowired
		private UserService userService;
		
		@RequestMapping(value = "/login.action", method = RequestMethod.POST)
		public String login(String usercode,String password, Model model, 
	                                                          HttpSession session) {
			// ͨ���˺ź������ѯ�û�
			User user = userService.findUser(usercode, password);
			if(user != null){		
				// ���û��������ӵ�Session
				session.setAttribute("USER_SESSION", user);
				// ��ת����ҳ��

				return "redirect:customer/list.action";
			}
			model.addAttribute("msg", "�˺Ż�����������������룡");
	         // ���ص���¼ҳ��
			return "login";
		}
		
		
		@RequestMapping(value = "/toCustomer.action")
		public String toCustomer() {
		    return "customer";
		}
		
		
		@RequestMapping(value = "/logout.action")
		public String logout(HttpSession session) {
		    // ���Session
		    session.invalidate();
		    // �ض��򵽵�¼ҳ�����ת����
		    return "redirect:login.action";
		}
		
		@RequestMapping(value = "/login.action", method = RequestMethod.GET)
		public String toLogin() {
		    return "login";
		}
		
		@RequestMapping(value="/registering.action")
		public String registering()
		{
			return "register";
		}
		
		@RequestMapping("/registered.action")
		public String register(User user)
		{
			System.out.println("�û���"+user.getUser_name()+" ����"+user.getUser_password());
			userService.addUser(user);
			return "login";
			
		}


	


}
